MATERIAL BINDER — <insert title here>

Blender source: build_binder.py
Schedule: embedded as SCHEDULE in the script; LVT-1 through RB-1 only.
Texture credits: binder/texture-sources.json. Images remain textures, not modeled surface patterns.

To rebuild, extract this archive into the Material Drawer checkout, then run:
blender --background --factory-startup --python binder/source/build_binder.py -- PATH_TO_CHECKOUT

Blender 5.2.3 LTS was used. Models use metres (1 inch = 0.0254 m); display units are inches.
The editable .blend has packed image textures, individual sample meshes, four animated page
pivots and a presentation camera. The GLB contains the same meshes and an 8-second animation.
Frames 0–48 turn the first page, then 48–96, 96–144, and 144–192.

Binder envelope reference:
https://store.vervante.com/viewoptions/InformationProducts.pdf, page 3
3-ring view binder: 11 x 11.5 inch covers, 3 inch spine, letter-size paper.
The mounting boards, fasteners, ring shape and clearance are modeled adaptations.

Cutting schedule:
Most swatches are cut to 2.5 x 2.5 inch squares; RB-1 is a 2 x 2 inch square.
Thickness is exactly the fraction in the supplied schedule, not the rounded Z column.
The default maximum mounted stack is 2.165 inches, including snap clearance.
Each material has a rear identification card and four modeled female snap sockets, one at each corner.
Four matching male studs stay on each mounting page. The web viewer detaches the actual
sample mesh, presents its back label, flips it, and returns it to its saved position.
The material itself keeps its original thickness; card stock and fasteners are separate meshes.
Image pattern scale is illustrative; material thickness and sample dimensions are geometric.

Textures: 15 matching product references, 2 manufacturer color references, 1 placeholder.
Product images and names belong to their respective manufacturers. Source URLs and status
are retained with each sample; the custom UTSW dark grey is explicitly approximate.

Viewer: Three.js r180, MIT license, LICENSE-three.txt in the main repository.

RETRACTABLE TETHERS
Each sample now has a RW5101 reel with the published 25.2 x 27.2 x 8.3 mm
envelope, 0.6 mm cable, 550 mm travel and 1/8 lb return force.
Run after the original binder builder:
blender --background --python build-tethers.py -- PATH_TO_CHECKOUT binder
node compact-glb.cjs binder-model.glb

The four corner snaps are retained. Each of the six positions per page has a left-side reel, including empty positions.
The cable's return force takes up slack; it is not a sample-hoisting mechanism.
The envelope is dimensioned from the manufacturer. Mounting saddles, recesses,
and housing surface details are a design proposal, not manufacturer CAD.
See tether-source.json for the source and product comparison.

NOVEMBER 4 WORKSHOP REVISION
After the base builders, tethers, and finishes, apply the new modeling pass:
blender --background --python build-client-notes.py -- PATH_TO_CHECKOUT
node compact-glb.cjs binder-model.glb case-model.glb wave-model.glb pockets-model.glb

The pass adds clear slide-in name sleeves, standard carriers, matching storage
assets, 3-inch-deep pocket cases with foam spacers, six-position binder pages,
folding covers and side panels, two-stage drawer slides, and carrier magnets.
Current downloadable .blend and .glb files already include this revision.
The compact drawer slides are a modeled nested-channel concept. The reference
is linked in each drawer data file. Fabrication tolerances require prototyping.