"""Build the Sample Room's dimensioned material binder in Blender.
Run: blender --background --factory-startup --python build_binder.py -- REPO
All model coordinates are metres; the schedule and fabrication dimensions use inches.
"""
import bpy, math, json, sys, pathlib, base64, textwrap
from fractions import Fraction
from mathutils import Vector

ROOT = pathlib.Path(sys.argv[sys.argv.index('--') + 1]).resolve()
INCH = .0254
def m(v): return v * INCH
SCHEDULE = [
 ('LVT-1','Interface','Brushed Lines','A01608 Sandalwood',4.5,19.5,3/16),
 ('LVT-2','Interface','Brushed Lines','UTSW Custom Dark Grey',9.5,9.5,1/8),
 ('LVT-3','Tarkett','iD Latitude Abstract','Greige 5103',6,6,1/8),
 ('LVT-4','Tarkett','iD Latitude Abstract','Cool Beige 3542',6,6,1/8),
 ('RT-1','Nora by Interface','Norament 992 Grano','5303 Frankincense',6,6,3/8),
 ('RT-2','Nora by Interface','Norament 926 Grano','5303 Frankincense',5.5,5.5,1/8),
 ('RT-3','Nora by Interface','Norament Castello','5354 Manor',6,6,1/8),
 ('SV-1','Tarkett','iQ Granit SD','950 Black Grey',9,12,1/16),
 ('SV-2','Mannington','BioSpec MD','15521 Blue Saturn',9,12,1/16),
 ('SV-3','Mannington','BioSpec','New Glacier',9,12,1/16),
 ('SV-4','Mannington','BioSpec MD','15421 Salt',9,12,1/16),
 ('EF-1','Stonhard','','Steel Gray Med Texture',2.75,2.75,5/16),
 ('EF-2','Stonhard','','Silver Gray Med Texture',2.75,2.75,5/16),
 ('CPT-1','Mannington','Estio','1413 Grand Cayman',24,24,1/4),
 ('CPT-2','Mannington','Stock','12288 Bonds',24,24,1/4),
 ('CPT-3','Mannington','Block Brights','12296 FDIC',24,24,1/4),
 ('CPT-4','Patcraft','I0317 Prado Modular','00595 Obsidian',24,24,1/4),
 ('RB-1','Roppe','','193 Black-Brown',2,2.5,1/16),
]
PAGES = [
 ('Luxury vinyl',['LVT-1','LVT-2','LVT-3','LVT-4']),
 ('Rubber',['RT-1','RT-2','RT-3','RB-1']),
 ('Sheet vinyl',['SV-1','SV-2','SV-3','SV-4']),
 ('Resin & carpet',['EF-1','EF-2','CPT-1','CPT-2','CPT-3','CPT-4']),
]
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.unit_settings.system='IMPERIAL'; scene.unit_settings.length_unit='INCHES'
scene.render.fps=24; scene.frame_start=0; scene.frame_end=192
scene.world.color=(.3,.3,.3)

def mat(name,color,metal=0,rough=.65):
    q=bpy.data.materials.new(name); q.diffuse_color=(*color,1); q.use_nodes=True
    bs=q.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Metallic'].default_value=metal; bs.inputs['Roughness'].default_value=rough
    return q
cover=mat('Warm grey bookcloth',(.24,.255,.245),rough=.9)
lining=mat('Warm ivory lining',(.68,.66,.59),rough=.9)
boardmat=mat('Charcoal mounting board',(.095,.11,.107),rough=.95)
metal=mat('Brushed nickel rings',(.56,.59,.58),.92,.24)
ink=mat('Ivory engraved lettering',(.78,.78,.70),rough=.8)
dark=mat('Snap back',(.045,.05,.048),.35,.5)
paper=mat('Back label paper',(.80,.78,.70),rough=.95)
labelink=mat('Back label ink',(.035,.055,.041),rough=.9)
MOUNT=.10

def box(name,xyz,dims,material,parent=None,bevel=0):
    bpy.ops.mesh.primitive_cube_add(size=1,location=tuple(m(a) for a in xyz)); o=bpy.context.object
    o.name=name; o.dimensions=tuple(m(a) for a in dims); bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if material:o.data.materials.append(material)
    if parent:o.parent=parent
    if bevel:
        mod=o.modifiers.new('Soft manufactured edges','BEVEL');mod.width=m(bevel);mod.segments=3
        o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    return o
def text(name,body,xyz,size,material,parent=None):
    curve=bpy.data.curves.new(name,'FONT');curve.body=body;curve.size=m(size);curve.extrude=0;curve.align_x='LEFT'
    o=bpy.data.objects.new(name,curve);scene.collection.objects.link(o);o.location=tuple(m(a) for a in xyz)
    o.data.materials.append(material)
    if parent:o.parent=parent
    # Export text as geometry so names are part of the Blender model and GLB.
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
    return o
def cylinder(name,xyz,r,depth,material,parent=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=m(r),depth=m(depth),location=tuple(m(a) for a in xyz))
    o=bpy.context.object;o.name=name;o.data.materials.append(material)
    if parent:o.parent=parent
    return o
def tube(name,points,r,material):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=m(r);c.bevel_resolution=3
    s=c.splines.new('POLY');s.points.add(len(points)-1)
    for p,xyz in zip(s.points,points):p.co=(*[m(a) for a in xyz],1)
    o=bpy.data.objects.new(name,c);scene.collection.objects.link(o);c.materials.append(material)
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
    return o
def socket(name,xyz,parent):
    x,y,z=xyz
    cylinder(name+'_flange',(x,y,z-.012),.15,.024,metal,parent)
    cylinder(name+'_recess',(x,y,z-.031),.075,.012,dark,parent)
    bpy.ops.mesh.primitive_torus_add(major_radius=m(.10),minor_radius=m(.023),major_segments=32,minor_segments=12,location=(m(x),m(y),m(z-.042)))
    o=bpy.context.object;o.name=name+'_socket';o.parent=parent;o.data.materials.append(metal)
    for face in o.data.polygons:face.use_smooth=True
    o['snap_half']='socket'
def stud(name,xyz,parent):
    x,y,z=xyz
    cylinder(name+'_flange',(x,y,z+.010),.15,.020,metal,parent)
    cylinder(name+'_neck',(x,y,z+.035),.055,.040,metal,parent)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=1,location=(m(x),m(y),m(z+.065)))
    o=bpy.context.object;o.name=name+'_stud';o.scale=(m(.085),m(.085),m(.03));bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.parent=parent;o.data.materials.append(metal);o['snap_half']='stud'
    for face in o.data.polygons:face.use_smooth=True
def frac(n):
    whole=int(n);remainder=Fraction(n-whole).limit_denominator(16)
    return (str(whole)+' ' if whole else '')+str(remainder) if remainder else str(whole)

# Published cover envelope: 11 x 11.5 in, 3 in spine. The book is displayed open.
box('Cover_right',(5.5,0,-.10),(11,11.5,.16),cover,bevel=.06)
box('Cover_left',(-8.5,0,-.10),(11,11.5,.16),cover,bevel=.06)
box('Spine_3_in',(-1.5,0,-.10),(3,11.5,.16),cover,bevel=.04)
box('Inside_right',(5.5,0,-.008),(10.75,11.24,.015),lining,bevel=.04)
box('Inside_left',(-8.5,0,-.008),(10.75,11.24,.015),lining,bevel=.04)
for x in [-3,0]:tube('Cover flexible hinge',[(x,-5.6,.015),(x,5.6,.015)],.025,dark)
box('Ring mechanism',(0,0,.065),(1.05,10.0,.14),metal,bevel=.08)
for y in [-4.25,0,4.25]:
    # Straight ring sides register all four punched pages at their different stack levels.
    points=[(.95,y,.12),(.95,y,1.90)]
    points += [(.95*math.cos(i*math.pi/64),y,1.90+.95*math.sin(i*math.pi/64)) for i in range(65)]
    points += [(-.95,y,.12)]
    points += [(.95*math.cos(math.pi+i*math.pi/64),y,.12+.08*math.sin(math.pi+i*math.pi/64)) for i in range(65)]
    tube('Round_ring',points,.043,metal)
    cylinder('Mechanism rivet',(0,y-.28,.15),.06,.02,metal)
text('Inner_cover_mark','THE SAMPLE ROOM',(-12.7,4.55,.025),.25,dark)
text('Inner_cover_subtitle','MATERIAL STUDIES / 01',(-12.7,4.16,.025),.13,dark)
text('Inner_cover_spec','LVT - RT - SV - EF - CPT - RB',(-12.7,-4.88,.025),.13,dark)

source=json.loads((ROOT/'binder/texture-sources.json').read_text(encoding='utf-8-sig'))
if isinstance(source,dict):sources=source.get('materials',source.get('textures',source.get('entries',[])))
else:sources=source
byid={q['id']:q for q in sources}
records={}; page_max=[]
for name,ids in PAGES:page_max.append(max(q[6] for q in SCHEDULE if q[0] in ids))
right=[]; z=.20
for thick in reversed(page_max):right.insert(0,z);z+=.06+MOUNT+thick+.10
left=[];z=.04
for thick in page_max:z+=.10+MOUNT+thick+.03;left.append(z);z+=.03
assert max(z,right[0]+page_max[0]+.03+MOUNT)<3, 'Stack exceeds spine'
pageobjs=[]
for pi,(name,ids) in enumerate(PAGES):
    pivot=bpy.data.objects.new('Page_%d'%(pi+1),None);scene.collection.objects.link(pivot);pageobjs.append(pivot)
    pivot['page_index']=pi;pivot['category']=name
    board=box('Mounting_page_%d'%(pi+1),(4.25,0,0),(8.5,11,.06),boardmat,pivot,bevel=.015)
    # Three punched holes in each rigid mounting board.
    for y in [-4.25,0,4.25]:
        hole=cylinder('Hole cutter',(.30,y,0),.15,.20,dark,pivot)
        bpy.context.view_layer.objects.active=board
        mod=board.modifiers.new('Ring hole','BOOLEAN');mod.operation='DIFFERENCE';mod.object=hole
        bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(hole,do_unlink=True)
    text('Page heading %d'%pi,'%02d / %s'%(pi+1,name.upper()),(.95,5.13,.034),.16,ink,pivot)
    for si,id in enumerate(ids):
        row=next(q for q in SCHEDULE if q[0]==id); _,maker,series,color,w,h,t=row
        cw=ch=min(w,h,2.5);x=[2.45,6.15][si%2];y=[3.48,-.04,-3.56][si//2]
        src=byid[id];path=src.get('path',src.get('localPath',src.get('local_path')))
        imagepath=ROOT/path
        if not imagepath.exists():imagepath=ROOT/'binder/textures'/pathlib.Path(path).name
        im=bpy.data.images.load(str(imagepath));im.pack()
        tm=mat(id+' product texture',(.5,.5,.5),rough=.91 if id.startswith('CPT') else .65)
        nodes=tm.node_tree.nodes; tex=nodes.new('ShaderNodeTexImage');tex.image=im
        tm.node_tree.links.new(tex.outputs['Color'],nodes.get('Principled BSDF').inputs['Base Color'])
        sample=box('Sample_'+id,(x,y,.03+MOUNT+t/2),(cw,ch,t),tm,pivot)
        rgb=tuple(int(src['colorHex'].lstrip('#')[i:i+2],16)/255 for i in (0,2,4))
        linear=tuple((c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4)*.75 for c in rgb)
        sample.data.materials.append(mat(id+' cut edge',linear,rough=.95))
        for face in sample.data.polygons:
            if abs(face.normal.z)<.9:face.material_index=1
        # Planar UVs retain the downloaded image as a texture; thickness remains mesh geometry.
        uv=sample.data.uv_layers.active or sample.data.uv_layers.new()
        for p in sample.data.polygons:
            for li in p.loop_indices:
                v=sample.data.vertices[sample.data.loops[li].vertex_index].co
                uv.data[li].uv=(v.x/m(min(w,3))+.5,v.y/m(min(h,2.5))+.5)
        sample['material_id']=id;sample['thickness_inches']=t;sample['cut_width_inches']=cw;sample['cut_height_inches']=ch
        sample['original_width_inches']=w;sample['original_height_inches']=h
        # The studs stay on the page; the sockets and identification card travel with the swatch.
        for sx in [-cw/2+.22,cw/2-.22]:
            for sy in [-ch/2+.22,ch/2-.22]:
                stud('Page_snap_'+id,(x+sx,y+sy,.03),pivot)
                socket('Sample_snap_'+id,(sx,sy,-t/2),sample)
        sample['snap_count']=4
        tag=bpy.data.objects.new('Back_card_'+id,None);scene.collection.objects.link(tag);tag.parent=sample
        tag.location=(0,0,m(-t/2-.012));tag.rotation_euler=(math.pi,0,0)
        lw,lh=cw-.80,ch-.85;scale=lw/1.70
        box('Card_stock_'+id,(0,0,0),(lw,lh,.014),paper,tag,bevel=.025)
        tx=-lw/2+.08;top=lh/2-.22*scale
        text('Back_ID_'+id,id,(tx,top,.009),.20*scale,labelink,tag)
        lines=textwrap.wrap(color,width=23)
        for li,line in enumerate(lines[:2]):text('Back_color_'+id+str(li),line,(tx,top-(.22+li*.14)*scale,.009),.10*scale,labelink,tag)
        text('Back_maker_'+id,maker,(tx,top-.66*scale,.009),.09*scale,labelink,tag)
        text('Back_series_'+id,series,(tx,top-.82*scale,.009),.08*scale,labelink,tag)
        text('Back_cut_'+id,'CUT  %s x %s in'%(frac(cw),frac(ch)),(tx,top-1.05*scale,.009),.09*scale,labelink,tag)
        text('Back_thickness_'+id,'THICKNESS  %s in'%frac(t),(tx,top-1.22*scale,.009),.09*scale,labelink,tag)
        text('Label_'+id,id+'  /  '+maker[:22],(x-cw/2,y-ch/2-.23,.034),.135,ink,pivot)
        text('Color_'+id,color[:31],(x-cw/2,y-ch/2-.43,.034),.115,ink,pivot)
        assert cw<=w and ch<=h and x-cw/2>.6 and x+cw/2<8.5 and abs(y)+ch/2<5
        records[id]={'id':id,'manufacturer':maker,'series':series,'color':color,'original':[w,h,t],
          'cut':[cw,ch,t],'page':pi,'source':src,'preview':'data:image/jpeg;base64,'+base64.b64encode(imagepath.read_bytes()).decode()}
    # Rigid mounted samples turn together with their page. Independent lift keeps stacked samples clear.
    for frame in range(0,193,2):
        progress=max(0,min(1,(frame-pi*48)/48));smooth=progress*progress*(3-2*progress)
        angle=-math.pi*smooth
        pivot.rotation_euler=(0,angle,0)
        lift=2.85-.30-(right[pi]+left[pi])/2
        pivot.location=(m(.65*(1-2*smooth)),0,m(right[pi]*(1-smooth)+left[pi]*smooth+lift*math.sin(math.pi*smooth)))
        pivot.keyframe_insert(data_path='rotation_euler',frame=frame);pivot.keyframe_insert(data_path='location',frame=frame)
    if pivot.animation_data and pivot.animation_data.action:pivot.animation_data.action.name='Turn_page_%d'%(pi+1)

scene.frame_set(0)
# Useful saved Blender camera and lighting, excluded from web GLB.
bpy.ops.object.camera_add(location=(m(18),m(-22),m(26)));camera=bpy.context.object;camera.name='Presentation_camera'
direction=Vector((m(-1),0,m(1)))-camera.location;camera.rotation_euler=direction.to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO';camera.data.ortho_scale=m(31);scene.camera=camera
for loc,power,size in [((8,-9,20),70,15),((-12,4,14),40,12)]:
    bpy.ops.object.light_add(type='AREA',location=tuple(m(a) for a in loc));o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=m(size)
    o.rotation_euler=(Vector((0,0,0))-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.render.resolution_x=1600;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'binder-model.blend'))
props=bpy.ops.export_scene.gltf.get_rna_type().properties.keys()
kw=dict(filepath=str(ROOT/'binder-model.glb'),export_format='GLB',export_animations=True,export_extras=True,
  export_apply=True,export_cameras=False,export_lights=False,export_frame_range=True,export_force_sampling=True)
if 'export_animation_mode' in props:kw['export_animation_mode']='SCENE'
if 'export_anim_scene_split_object' in props:kw['export_anim_scene_split_object']=False
bpy.ops.export_scene.gltf(**kw)
data={'version':3,'units':'inches','binder':{'cover':[11,11.5],'spine':3,'page':[8.5,11],
 'source':'https://store.vervante.com/viewoptions/InformationProducts.pdf','sourcePage':3},
 'pages':[{'title':name,'materials':ids} for name,ids in PAGES], 'materials':[records[q[0]] for q in SCHEDULE],
 'animation':{'duration':8,'turnDuration':2,'frames':193,'fps':24},
 'validation':{'sampleCount':len(records),'allThicknessesPreserved':True,'allCutsWithinOriginal':True,'allCutsSquare':True,'snapsPerSample':4,
 'rightStackHeightInches':right[0]+page_max[0]+.03+MOUNT,'leftStackHeightInches':z,'spineCapacityInches':3}}
(ROOT/'binder-data.json').write_text(json.dumps(data,separators=(',',':')),encoding='utf-8')
print('BINDER_VALIDATION',json.dumps(data['validation']))
