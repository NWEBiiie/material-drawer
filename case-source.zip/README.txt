SLANTED MATERIAL CASE

Blender 5.2.3; geometry uses metres, listed dimensions are inches.
Closed case: 9 x 12 x 6 inches. Tray depth: 2.75 inches.
Eighteen removable boards lean 25 degrees from vertical in fitted foam slots.
Each RW5101 reel lies parallel to its board, beneath the slot, with its outlet
pointing toward the board. Material dimensions and thicknesses are unchanged.

Extract into the Material Drawer checkout and rebuild:
blender --background --python build-case.py -- PATH_TO_CHECKOUT
blender --background --python build-tethers.py -- PATH_TO_CHECKOUT case
node compact-glb.cjs case-model.glb

The supplied binder-model.blend contains the packed sample textures.
Reel dimensions, product source and comparison notes: tether-source.json.
Reel housings and mounts are design models, not manufacturer CAD.
The reel takes up cable slack; it is not intended to hoist material weight.
The browser viewer animates the cable between the exported tether nodes.

NOVEMBER 4 WORKSHOP REVISION
After the base builders, tethers, and finishes, apply the new modeling pass:
blender --background --python build-client-notes.py -- PATH_TO_CHECKOUT
node compact-glb.cjs binder-model.glb case-model.glb wave-model.glb pockets-model.glb

The pass adds clear slide-in name sleeves, standard carriers, matching storage
assets, 3-inch-deep pocket cases with foam spacers, six-position binder pages,
folding covers and side panels, two-stage drawer slides, and carrier magnets.
Current downloadable .blend and .glb files already include this revision.
The compact drawer slides are a modeled nested-channel concept. The reference
is linked in each drawer data file. Fabrication tolerances require prototyping.