SLANTED MATERIAL CASE

Blender 5.2.3; geometry uses metres, listed dimensions are inches.
Closed case: 8.35 x 11.7 x 5.85 inches. Tray depth: 2.75 inches.
Eighteen removable boards lean 25 degrees from vertical in fitted foam slots.
Each RW5101 reel lies parallel to its board, beneath the slot, with its outlet
pointing toward the board. Material dimensions and thicknesses are unchanged.

Extract into the Material Drawer checkout and rebuild:
blender --background --python build-case.py -- PATH_TO_CHECKOUT
blender --background --python build-tethers.py -- PATH_TO_CHECKOUT case
node compact-glb.cjs case-model.glb

The supplied binder-model.blend contains the packed sample textures.
Reel dimensions, product source and comparison notes: tether-source.json.
Reel housings and mounts are design models, not manufacturer CAD.
The reel takes up cable slack; it is not intended to hoist material weight.
The browser viewer animates the cable between the exported tether nodes.
