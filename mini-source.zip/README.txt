SMALL MATERIAL STUDIES — BLENDER SOURCE

Uses packed material textures in binder-model.blend.
Units in build-mini-studies.py are inches. GLB outputs use metres.

Run with Blender 5.2 or newer:
  blender --background --python build-mini-studies.py -- PATH_TO_THIS_FOLDER
  blender --background --python build-tethers.py -- PATH_TO_THIS_FOLDER wave pockets

To rebuild only the blue fabric/plastic wave drawer, append wave to the first command.
Compact exported GLBs without changing geometry or animation:
  node compact-glb.cjs wave-model.glb
  node compact-glb.cjs pockets-model.glb

The drawer has thin pearl polypropylene edges, woven blue cover panels and soft webbing pulls.
Palette reference: https://brand.utswmed.org/color-palette-and-typography/
UT Southwestern blue #004c97; cyan accent #009ee2. No institutional logo is used.
Procedural weave is generated and packed by the builder.

All eighteen 1.5-inch square material cuts preserve their supplied thicknesses.
Retractable housings reference the RUIWOR RW5101; see tether-source.json.
Cam mechanism remains a kinematic concept; loads and manufacturing tolerances are not sized.
