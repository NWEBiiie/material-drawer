Extract into the Material Drawer checkout. Blender 5.2.3 was used.
Rebuild the base geometry:
blender --background --python build-mini-studies.py -- PATH_TO_CHECKOUT
Add the dimensioned reel housings and cables:
blender --background --python build-tethers.py -- PATH_TO_CHECKOUT wave pockets
Then optimize each resulting GLB with node compact-glb.cjs MODEL.glb.

Reel source, dimensions and selection notes: tether-source.json.
Housing surface details and adapter mounts are design proposals.
The reel retracts cable slack; it is not intended to hoist material weight.
Sample thickness, square cuts and existing animations remain unchanged.
The web viewer drives continuous cables between modeled outlet and eyelet nodes.
