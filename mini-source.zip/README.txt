REVISED MATERIAL COLLECTION — 75 MATERIALS

Extract this archive into an empty directory. Blender and Node.js are required.
The original binder builder is a construction template; the revised builders
replace its embedded schedule with material-schedule.json. Follow the full
rebuild sequence below to create all six volumes and their storage assets.
RS-1, RS-2 and TZ-1 use explicitly flagged dimension proxies.
Image provenance and unresolved references are recorded in material-schedule.json.

# Material volumes and inventory

The revised schedule received November 11, 2026 is recorded in `material-schedule.json`: Flooring (21), Paint (11), Tile & grout (10), Surfaces (16), Wall protection (7), and Specialties (10), for 75 materials. RS-1, RS-2, and TZ-1 are new. Product identities, images, and inventory selections follow the renumbered entries. The matrix migrates saved inventory from v1 IDs to v2 IDs without overwriting an existing v2 choice.

Blank and N/A values remain unknown. The new flooring entries retain a 0.02-inch thickness proxy; these are not measured product dimensions. The chart's LVT-1, WT-1, and CC-2 product/filename differences remain visible as notes. CC lengths are 36+ inches, with 36 stored as the stated minimum. The prior PT-11 manufacturer conflict is resolved by the revised chart.

The November 11 texture update adds or replaces 46 swatches and color references using the manufacturer sources recorded in `material-schedule.json`. In total, 61 materials have sourced images or color references; 14 retain labeled placeholders because an exact texture, custom color, finish, or product identity could not be confirmed. Source links and product-image/color-reference/placeholder labels appear in the matrix. RS-1 uses the Fjord woodgrain, RS-2 uses the Pepperwood directional rubber swatch, and WT-1 uses Mocha 1622. Screen colors and image scale are references, not physical sample approvals. Geometry, dimensions, animation, and the six 21-slot pocket boxes are unchanged.

To refresh textures without rebuilding geometry, run `python refresh-material-textures.py`, then Blender with `--background --factory-startup --python refresh-blender-textures.py -- REPO`, and finally `python package-sources.py`. Editable images are included in the source packages. The texture refresh preserves mesh and animation data and shares duplicate binary buffers losslessly.

All six binders use two-inch square cuts on a uniform 3.6-inch grid, four corner snaps and a left-midpoint tether. The flooring binder uses four pages with 21 occupied positions. The flooring slanted case retains its 9 × 12 × 6-inch envelope with 11/10 carriers. All six pocket boxes are 13.5 × 8 × 3 inches, with three rows of seven slots for 1.5-inch samples; unused slots remain open. The 5 × 13 × 7-inch wave body retains its handle, nested slides, and both cam and belt drives; 21 stations use checked variable spacing. Known material thicknesses are never reduced to obtain a fit.

Each format supports `volume=1` through `volume=6`. The matrix separates the revised schedule, texture status, and editable physical inventory. Model review edits and the archived custom material library remain browser-local; the exterior finish follows the published default. Changed socket geometry uses a new storage version so earlier offsets are not assigned to different products.

Rebuild in order: `node build-material-volumes.cjs`, then run Blender with `--background --factory-startup --python SCRIPT -- REPO` for `build-volume-binders.py`, `build-all-volumes.py`, `build-client-notes.py`, `build-belt-alternative.py`, and `export-storage-models.py`. Extract `binder-source.zip` first to restore the original binder template and textures. The workshop pass restores all mount, sleeve, magnet and slide revisions. Then run the material-only `apply-exterior-finish.py` pass in Blender. Finally run `node build-storage.cjs` and lossless `compact-glb.cjs` on all exported GLBs.

Validation: `node check-material-volumes.cjs`, `node check-collection.cjs`, and Blender `check-workshop.py` / `check-belt-clearance.py`. These verify actual mesh sizes, known thickness, counts, mounting hardware, every-frame binder reel clearance, closed-case bounds, pocket magnets, slide overlap, belt passages, and six-volume shelf fit. The mechanisms remain kinematic concepts; loads, spring rates, belt material and fabrication tolerances require physical prototyping.
