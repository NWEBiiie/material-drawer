SMALL MATERIAL STUDIES — BLENDER SOURCE

Uses packed material textures in binder-model.blend.
Units in build-mini-studies.py are inches. GLB outputs use metres.

Run with Blender 5.2 or newer:
  blender --background --python build-mini-studies.py -- PATH_TO_THIS_FOLDER
  blender --background --python build-tethers.py -- PATH_TO_THIS_FOLDER wave pockets

To rebuild only the padded blue fabric wave drawer, append wave to the first command.
Compact exported GLBs without changing geometry or animation:
  node compact-glb.cjs wave-model.glb
  node compact-glb.cjs pockets-model.glb

The drawer has padded woven panels, opaque cloth sides, sewn navy binding and soft webbing pulls.
Palette reference: https://brand.utswmed.org/color-palette-and-typography/
UT Southwestern blue #004c97; cyan accent #009ee2. No institutional logo is used.
Procedural weave and thread normal maps are generated and packed by the builder. The drawer travels 12.4 inches to clear its rearmost carrier.

All eighteen 1.5-inch square material cuts preserve their supplied thicknesses.
Retractable housings reference the RUIWOR RW5101; see tether-source.json.
Cam mechanism remains a kinematic concept; loads and manufacturing tolerances are not sized.

Wave carry case: upper drawer removed; 7.06-inch textile body with raised padded luggage handle and reinforced sewn anchors. All sample thicknesses and moving mechanisms retained.
