SMALL MATERIAL STUDIES — BLENDER SOURCE

Uses packed material textures in binder-model.blend.
Units in build-mini-studies.py are inches. GLB outputs use metres.

Run with Blender 5.2 or newer:
  blender --background --python build-mini-studies.py -- PATH_TO_THIS_FOLDER
  blender --background --python build-tethers.py -- PATH_TO_THIS_FOLDER wave pockets

To rebuild only the padded blue fabric wave drawer, append wave to the first command.
Compact exported GLBs without changing geometry or animation:
  node compact-glb.cjs wave-model.glb
  node compact-glb.cjs pockets-model.glb

The drawer has padded woven panels, opaque cloth sides, sewn navy binding and soft webbing pulls.
Palette reference: https://brand.utswmed.org/color-palette-and-typography/
UT Southwestern blue #004c97; cyan accent #009ee2. No institutional logo is used.
Procedural weave and thread normal maps are generated and packed by the builder. The drawer travels 12.4 inches to clear its rearmost carrier.

All eighteen 1.5-inch square material cuts preserve their supplied thicknesses.
Retractable housings reference the RUIWOR RW5101; see tether-source.json.
Cam mechanism remains a kinematic concept; loads and manufacturing tolerances are not sized.

Wave carry case: upper drawer removed; exact 5 × 13 × 7-inch textile body (width × depth × height, excluding handle) with raised padded luggage handle and reinforced sewn anchors. Tray width, side rails, guide anchors, and reel mounts are fitted to the new 5-inch body. All sample thicknesses and cam mechanism dimensions are retained.

Pocket box: 12 x 8 x 3 inches closed, with three rows of six fitted foam recesses. Append pockets to the first command to rebuild only this box.

NOVEMBER 4 WORKSHOP REVISION
After the base builders, tethers, and finishes, apply the new modeling pass:
blender --background --python build-client-notes.py -- PATH_TO_CHECKOUT
node compact-glb.cjs binder-model.glb case-model.glb wave-model.glb pockets-model.glb

The pass adds clear slide-in name sleeves, standard carriers, matching storage
assets, 3-inch-deep pocket cases with foam spacers, six-position binder pages,
folding covers and side panels, two-stage drawer slides, and carrier magnets.
Current downloadable .blend and .glb files already include this revision.
The compact drawer slides are a modeled nested-channel concept. The reference
is linked in each drawer data file. Fabrication tolerances require prototyping.